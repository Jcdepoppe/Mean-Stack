function Ninja(name) {
    this.name = name;
    this.health = 100;
    var speed = 3;
    var strength = 3;

    this.readSpeed = function(){
        return speed;
    }
    this.readStrength = function(){
        return strength;
    }
}
Ninja.prototype.sayName = function() {
    console.log(this.name);
}
Ninja.prototype.showStats = function() {
    console.log(`Name: ${this.name}`);
    console.log(`Health: ${this.health}`);
    console.log(`Speed: ${this.readSpeed()}`);
    console.log(`Strength: ${this.readStrength()}`);
}

Ninja.prototype.drinkSake = function(){
    this.health += 10;
}

var ninja1 = new Ninja("Hyabusa");
ninja1.sayName();

ninja1.showStats();