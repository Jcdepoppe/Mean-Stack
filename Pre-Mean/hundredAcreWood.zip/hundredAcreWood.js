
var tigger = { character: "Tigger" };
var pooh = { character: "Winnie the Pooh"};
tigger.north = pooh;
pooh.south = tigger;

var piglet = { character: "Piglet" };
piglet.east = tigger.north;
tigger.north.west = piglet;

var bees = { character: "Bees" };
bees.west = tigger.north;
tigger.north.east = bees;

var robin = { character: "Christopher Robin"};
pooh.north = robin;
robin.south = pooh;

var owl = { character: "Owl" };
robin.west = owl;
piglet.north = owl;
owl.east = robin;
owl.south = piglet;

var rabbit = { character: "Rabbit"};
bees.north = rabbit;
robin.east = rabbit;
rabbit.south = bees;
rabbit.west = robin;

var gopher = { character: "Gopher" };
rabbit.east = gopher;
gopher.west = rabbit;

var kanga = { character: "Kanga"};
robin.north = kanga;
kanga.south = robin;

var eeyore = { character: "Eeyore"};
kanga.north = eeyore;
eeyore.south = kanga;

var heff = { character: "Heffalumps"};
eeyore.east = heff;
heff.west = eeyore;

var player = {
    location: tigger
}
