var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/messageBoard');

const PeopleSchema = new mongoose.Schema({
    name: {type: String}
}, {timestamps: true});

module.exports = mongoose.model("People", PeopleSchema);